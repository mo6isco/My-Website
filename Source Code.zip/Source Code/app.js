// Mobile menu toggle
const navMenu = document.getElementById('navbar__menu');
const navBtn = document.querySelector('.navbar__btn');

navBtn.addEventListener('click', () => {
  navMenu.classList.toggle('active');
  navBtn.classList.toggle('open');
});

window.addEventListener('resize', () => {
  if (window.innerWidth > 768) {
    navMenu.classList.remove('active');
    navBtn.classList.remove('open');
  }
});

// Smooth scrolling
const links = document.querySelectorAll('a[href^="#"]');

links.forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const target = document.querySelector(e.target.getAttribute('href'));
    target.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  });
});

// Accordion for FAQ section
const accordionBtns = document.querySelectorAll('.accordion__btn');

accordionBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    btn.classList.toggle('active');
    const panel = btn.nextElementSibling;
    if (panel.style.maxHeight) {
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + 'px';
    }
  });
});

// Responsive image gallery
const gallery = document.querySelector('.gallery');
const images = gallery.querySelectorAll('img');

images.forEach(img => {
  img.addEventListener('click', () => {
    gallery.classList.add('active');
    const modal = document.createElement('div');
    modal.classList.add('modal');
    const modalImg = document.createElement('img');
    modalImg.src = img.src;
    modal.appendChild(modalImg);
    gallery.appendChild(modal);
    modal.addEventListener('click', () => {
      gallery.classList.remove('active');
      modal.remove();
    });
  });
});

// Responsive hero section
const heroContent = document.querySelector('.main__content');
const heroImage = document.querySelector('.main__image');

function adjustHeroLayout() {
  if (window.innerWidth < 768) {
    heroContent.style.textAlign = 'center';
    heroImage.style.marginTop = '30px';
  } else {
    heroContent.style.textAlign = 'left';
    heroImage.style.marginTop = '0';
  }
}

window.addEventListener('resize', adjustHeroLayout);
adjustHeroLayout();

// Responsive body sections
const bodySections = document.querySelectorAll('.body-section');

function adjustBodySections() {
  bodySections.forEach(section => {
    if (window.innerWidth < 768) {
      section.style.flexDirection = 'column';
      section.style.textAlign = 'center';
    } else {
      section.style.flexDirection = 'row';
      section.style.textAlign = 'left';
    }
  });
}

window.addEventListener('resize', adjustBodySections);
adjustBodySections();